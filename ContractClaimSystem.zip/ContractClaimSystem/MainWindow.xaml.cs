﻿using System.Collections.Generic;
using System.Windows;

namespace ContractClaimSystem
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Mock data for Lecturer claims
            var lecturerClaims = new List<dynamic>
            {
                new { ClaimId = "C001", Month = "August", Programme = "IT", Amount = "R5000", Status = "Submitted" },
                new { ClaimId = "C002", Month = "July", Programme = "Business", Amount = "R4500", Status = "Approved" }
            };

            // Mock data for Approvals
            var approvals = new List<dynamic>
            {
                new { ClaimId = "C003", Lecturer = "John Doe", Programme = "IT", Amount = "R5200" },
                new { ClaimId = "C004", Lecturer = "Jane Smith", Programme = "Accounting", Amount = "R4700" }
            };

            LecturerClaimsGrid.ItemsSource = lecturerClaims;
            ApprovalsGrid.ItemsSource = approvals;
        }

        // === Event Handlers (prototype, no real Database logic) ===
        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Claim submitted successfully!", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void UploadDocs_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Documents uploaded successfully!", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ApproveClaim_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Claim approved!", "Approval", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void RejectClaim_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Claim rejected!", "Rejection", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }
}
